import React from 'react';
import { Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';

interface SettleCompleteModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  onKeep?: () => void;
  onKeepWithHistory?: () => void;
  onKeepAndClearHistory?: () => void;
  onDelete: () => void;
  isLoading?: boolean;
}

export const SettleCompleteModal: React.FC<SettleCompleteModalProps> = ({
  isOpen,
  debtor,
  onKeep,
  onKeepWithHistory,
  onKeepAndClearHistory,
  onDelete,
  isLoading = false,
}) => {
  const { t, currency } = useI18n();

  if (!isOpen || !debtor) return null;

  const isCreditor = debtor.type === 'creditor';

  const handleKeepWithHistory = () => {
    if (onKeepWithHistory) {
      onKeepWithHistory();
    } else if (onKeep) {
      onKeep();
    }
  };

  const handleKeepAndClearHistory = () => {
    if (onKeepAndClearHistory) {
      onKeepAndClearHistory();
    } else if (onKeep) {
      onKeep();
    }
  };

  const badgeText = isCreditor
    ? t('creditors.settledBadge', 'مسدد بالكامل')
    : t('status.debtFree', 'خالي من الدين');

  const titleText = isCreditor
    ? t('creditors.fullSettledTitle', 'تم تسديد كامل المستحقات للدائن')
    : t('debts.fullDebtSettledTitle', 'تم تسديد كامل المبلغ');

  const descText = isCreditor
    ? `${t('creditors.fullSettledDesc', 'تم تسديد كافة المستحقات المطلوبة للدائن بالكامل وأصبح رصيده')} `
    : `${t('debts.fullDebtSettledDesc', 'قام المدين بتسديد كافة المستحقات المترتبة بذمته بالكامل وأصبح رصيده')} `;

  const promptText = isCreditor
    ? t('creditors.settleChoicePrompt', 'يرجى تحديد الإجراء المطلوب لحساب الدائن:')
    : t('debts.settleKeepOrDeletePrompt', 'يرجى تحديد الإجراء المطلوب لحساب المدين:');

  const keepWithHistoryTitle = isCreditor
    ? t('creditors.keepWithHistoryTitle', 'الاحتفاظ بالدائن مع سجلاته القديمة')
    : t('debts.keepDebtorRecord', 'الاحتفاظ بالمدين مع سجلاته القديمة');

  const keepWithHistoryDesc = isCreditor
    ? t('creditors.keepWithHistoryDesc', 'الإبقاء عليه في السجل كمسدد مع حفظ كامل تاريخ الدفعات')
    : t('debts.keepWithHistoryDesc', 'الإبقاء عليه في السجل ضمن قائمة "خالي من الدين" مع حفظ تاريخ الحركات');

  const keepAndClearTitle = isCreditor
    ? t('creditors.keepAndClearTitle', 'الاحتفاظ بالدائن مع حذف سجلاته القديمة')
    : t('debts.keepAndClearTitle', 'الاحتفاظ بالمدين مع حذف سجلاته القديمة');

  const keepAndClearDesc = isCreditor
    ? t('creditors.keepAndClearDesc', 'الإبقاء على بيانات الدائن وتصفير الرصيد وبدء صفحة جديدة')
    : t('debts.keepAndClearDesc', 'الإبقاء على الاسم والبيانات الأساسية وتصفير الرصيد وبدء صفحة جديدة');

  const deleteTitle = isCreditor
    ? t('creditors.deleteCreditorPermanently', 'حذف الدائن نهائياً')
    : t('debtors.deleteDebtorPermanently', 'حذف المدين نهائياً');

  const deleteDesc = isCreditor
    ? t('creditors.deleteCreditorDesc', 'إزالة حساب الدائن وكافة سجلاته بشكل نهائي من قاعدة البيانات')
    : t('debtors.deleteDebtorDesc', 'إزالة حساب المدين وكافة سجلاته بشكل نهائي من قاعدة البيانات');

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 select-none">
      <div
        className="bg-white rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl relative border border-slate-100 text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Success / Settlement Icon */}
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl mx-auto mb-3 shadow-sm border border-emerald-100">
          <i className="fa-solid fa-circle-check"></i>
        </div>

        <span className="text-[11px] font-bold bg-emerald-100/70 text-emerald-800 px-3 py-1 rounded-full inline-block mb-2">
          {badgeText}
        </span>

        <h3 className="font-black text-base sm:text-lg text-slate-800 mb-1.5">
          {titleText}
        </h3>

        <p className="text-xs text-slate-500 mb-3 leading-relaxed">
          {descText}
          <span className="font-bold text-slate-800 mx-1">{debtor.name}</span>
          <span className="font-mono font-bold text-emerald-600">0 {currency}</span>.
        </p>

        <p className="text-[11.5px] font-semibold text-slate-600 mb-4 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
          {promptText}
        </p>

        {/* 3 Action Options */}
        <div className="flex flex-col gap-2.5 text-start">
          {/* Option 1: Keep with old history intact */}
          <button
            type="button"
            onClick={handleKeepWithHistory}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-blue-50/70 hover:bg-blue-100/80 active:scale-[0.99] border border-blue-200/80 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-solid fa-box-archive"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-blue-950 group-hover:text-blue-900 flex items-center justify-between">
                  <span>{keepWithHistoryTitle}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-blue-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-blue-700/80 mt-0.5 leading-tight">
                  {keepWithHistoryDesc}
                </p>
              </div>
            </div>
          </button>

          {/* Option 2: Keep debtor profile but clear old history (new clean page) */}
          <button
            type="button"
            onClick={handleKeepAndClearHistory}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-teal-50/70 hover:bg-teal-100/80 active:scale-[0.99] border border-teal-200/80 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-solid fa-rotate-right"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-teal-950 group-hover:text-teal-900 flex items-center justify-between">
                  <span>{keepAndClearTitle}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-teal-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-teal-700/80 mt-0.5 leading-tight">
                  {keepAndClearDesc}
                </p>
              </div>
            </div>
          </button>

          {/* Option 3: Permanently delete debtor */}
          <button
            type="button"
            onClick={onDelete}
            disabled={isLoading}
            className="w-full p-3 rounded-2xl bg-rose-50/60 hover:bg-rose-100/80 active:scale-[0.99] border border-rose-200/80 transition-all group cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center text-sm shrink-0 shadow-xs">
                <i className="fa-regular fa-trash-can"></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-xs text-rose-950 group-hover:text-rose-900 flex items-center justify-between">
                  <span>{deleteTitle}</span>
                  <i className="fa-solid fa-chevron-left text-[10px] text-rose-400 group-hover:translate-x-[-2px] transition-transform"></i>
                </div>
                <p className="text-[10px] text-rose-700/80 mt-0.5 leading-tight">
                  {deleteDesc}
                </p>
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
