import React, { useState, useMemo, useRef, useEffect } from 'react';
import { AppSettings, Debtor, DebtorTransaction, DebtStats, User, InstallmentRecord, Supplier } from '../types';
import { formatNumber, formatDateDigits, formatFullDateTime } from '../utils/formatters';
import { getUserBranchDisplayName, getUserDisplayName } from '../utils/userUtils';
import { printSystemPdfReport } from '../utils/pdfReportGenerator';
import { getLocalDebtorHistory } from '../services/turso';
import { generateDebtorsTextReport, shareTextFile } from '../utils/textReportExporter';
import { InstallmentsReport } from './InstallmentsReport';
import { SuppliersReport } from './SuppliersReport';
import { CreditorsReport } from './CreditorsReport';
import { useI18n } from '../i18n/index.tsx';

export type ReportMode = 'debts' | 'creditors' | 'installments' | 'suppliers';
export type ReportFilterPeriod = 'today' | 'week' | 'month' | 'last_month' | 'custom' | 'all';
export type TxTypeFilter = 'all' | 'add' | 'pay';

interface EnrichedTransaction extends DebtorTransaction {
  debtorId: number;
  debtorName: string;
  debtorPhone?: string;
  debtorType?: 'debtor' | 'creditor';
}

interface DebtorGroupSummary {
  debtorId: number;
  debtorName: string;
  debtorPhone?: string;
  debtorType?: 'debtor' | 'creditor';
  currentTotalDebt: number;
  periodAdded: number;
  periodPaid: number;
  periodNet: number;
  addsCount: number;
  paysCount: number;
  transactions: EnrichedTransaction[];
}

interface ReportsTabProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  stats: DebtStats;
  settings?: AppSettings;
  mode?: ReportMode;
  isActive?: boolean;
  onUpdateStats?: (newStats: DebtStats) => void;
  onResetStats?: () => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ReportsTab: React.FC<ReportsTabProps> = React.memo(({
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  stats,
  mode,
  isActive = true,
  onResetStats,
  onShowToast,
}) => {
  const { t, numberFormat, currency } = useI18n();

  // ----------------------------------------------------
  // State: Report Mode (Debts vs Installments)
  // ----------------------------------------------------
  const canSwitchModules =
    currentUser.role === 'admin' ||
    !currentUser.allowedModules ||
    currentUser.allowedModules === 'both';

  const initialMode: ReportMode =
    currentUser.allowedModules === 'installments'
      ? 'installments'
      : currentUser.allowedModules === 'debts'
      ? 'debts'
      : mode || 'debts';

  const [reportMode, setReportMode] = useState<ReportMode>(initialMode);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync mode with prop or user permission if provided
  useEffect(() => {
    if (currentUser.allowedModules === 'installments') {
      setReportMode('installments');
    } else if (currentUser.allowedModules === 'debts') {
      setReportMode('debts');
    } else if (mode) {
      setReportMode(mode);
    }
  }, [mode, currentUser.allowedModules]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  // ----------------------------------------------------
  // State: Filter period, custom dates, expanded cards, and search/type
  // ----------------------------------------------------
  const [filterPeriod, setFilterPeriod] = useState<ReportFilterPeriod>('all');
  
  // Custom date picker state
  const todayIso = new Date().toISOString().split('T')[0];
  const [customStartDate, setCustomStartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(1); // 1st of current month
    return d.toISOString().split('T')[0];
  });
  const [customEndDate, setCustomEndDate] = useState<string>(todayIso);

  // Table filters & search
  const [txSearchTerm, setTxSearchTerm] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState<TxTypeFilter>('all');
  const [copiedReport, setCopiedReport] = useState(false);

  // Expanded Accordion State (Debtor IDs that are open)
  const [expandedDebtorIds, setExpandedDebtorIds] = useState<Set<number>>(new Set());
  const [visibleGroupsLimit, setVisibleGroupsLimit] = useState(30);

  useEffect(() => {
    setVisibleGroupsLimit(30);
  }, [filterPeriod, txTypeFilter, txSearchTerm]);

  const toggleDebtorExpanded = (debtorId: number) => {
    setExpandedDebtorIds((prev) => {
      const next = new Set(prev);
      if (next.has(debtorId)) {
        next.delete(debtorId);
      } else {
        next.add(debtorId);
      }
      return next;
    });
  };

  const expandAllDebtors = (ids: number[]) => {
    setExpandedDebtorIds(new Set(ids));
  };

  const collapseAllDebtors = () => {
    setExpandedDebtorIds(new Set());
  };

  // Filter debtors for debts report (strictly customer debts - not creditors)
  const filteredDebtorsByCategory = useMemo(() => {
    return debtors.filter((d) => d.type !== 'creditor');
  }, [debtors]);

  // ----------------------------------------------------
  // Aggregate all transactions from debtors & localStorage
  // ----------------------------------------------------
  const allTransactions = useMemo<EnrichedTransaction[]>(() => {
    if (!currentUser || !isActive) return [];
    const historyMap = getLocalDebtorHistory(currentUser.id);
    const list: EnrichedTransaction[] = [];
    const seenKeys = new Set<string>();

    const targetDebtors = filteredDebtorsByCategory;
    const maxDebtorsToCheck = Math.min(targetDebtors.length, 1000);
    for (let i = 0; i < maxDebtorsToCheck; i++) {
      const debtor = targetDebtors[i];
      if (!debtor) continue;
      const isDemo = debtor.isDemo || (typeof debtor.id === 'number' && debtor.id < 0);

      // 1. Transactions from debtor.history array or local storage history map (skip map for demo)
      const debtorHist: DebtorTransaction[] = debtor.history || (!isDemo ? historyMap[debtor.id] : undefined) || [];

      for (let j = 0; j < debtorHist.length; j++) {
        const tx = debtorHist[j];
        const key = `${debtor.id}_${tx.id || tx.date}_${tx.amount}_${tx.type}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          list.push({
            ...tx,
            debtorId: debtor.id,
            debtorName: debtor.name,
            debtorPhone: debtor.phone,
            debtorType: debtor.type || 'debtor',
          });
        }
      }

      // 2. Fallback: If debtor was created with initial debt and has no history entries (only for real debtors)
      if (!isDemo && debtorHist.length === 0 && (Number(debtor.amount) || 0) > 0) {
        const key = `${debtor.id}_initial_${debtor.amount}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          list.push({
            id: `initial_${debtor.id}`,
            type: 'add',
            amount: Number(debtor.amount) || 0,
            balanceAfter: Number(debtor.amount) || 0,
            date: debtor.createdAt || new Date().toISOString(),
            description: debtor.notes || (debtor.type === 'creditor' ? 'فتح حساب دين عليّ' : t('reports.initialBalance', 'رصيد افتتاحي / دين سابق')),
            notes: debtor.notes,
            debtorId: debtor.id,
            debtorName: debtor.name,
            debtorPhone: debtor.phone,
            debtorType: debtor.type || 'debtor',
          });
        }
      }
    }

    // Sort descending by date (newest first)
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [filteredDebtorsByCategory, currentUser, t, isActive]);

  // ----------------------------------------------------
  // Calculate Date Boundaries for Selected Filter
  // ----------------------------------------------------
  const { periodLabel, isDateInRange } = useMemo(() => {
    const now = new Date();
    
    // Start and end of today
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    // Start and end of this week (last 7 days)
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfWeek.getDate() - 6);

    // Start and end of this month
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

    // Start and end of previous month
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);

    let label = t('reports.allPeriods', 'الإجمالي العام لكافة الفترات');
    let checkFn = (_date: Date) => true;

    if (filterPeriod === 'today') {
      label = `${t('reports.today', 'اليوم')} (${formatDateDigits(now.toISOString().split('T')[0], numberFormat)})`;
      checkFn = (d: Date) => d >= startOfToday && d <= endOfToday;
    } else if (filterPeriod === 'week') {
      label = t('reports.thisWeek', 'هذا الأسبوع (آخر 7 أيام)');
      checkFn = (d: Date) => d >= startOfWeek && d <= endOfToday;
    } else if (filterPeriod === 'month') {
      label = `${t('reports.thisMonth', 'هذا الشهر')} (${formatDateDigits(`${now.getFullYear()}-${now.getMonth() + 1}`, numberFormat)})`;
      checkFn = (d: Date) => d >= startOfMonth && d <= endOfMonth;
    } else if (filterPeriod === 'last_month') {
      const prevMonthIdx = (now.getMonth() + 11) % 12;
      const prevMonthYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
      label = `${t('reports.lastMonth', 'الشهر السابق')} (${formatDateDigits(`${prevMonthYear}-${prevMonthIdx + 1}`, numberFormat)})`;
      checkFn = (d: Date) => d >= startOfLastMonth && d <= endOfLastMonth;
    } else if (filterPeriod === 'custom') {
      const start = customStartDate ? new Date(`${customStartDate}T00:00:00`) : new Date(0);
      const end = customEndDate ? new Date(`${customEndDate}T23:59:59.999`) : new Date();
      label = `${t('reports.customPeriod', 'فترة مخصصة')} (${formatDateDigits(customStartDate || '', numberFormat)} - ${formatDateDigits(customEndDate || '', numberFormat)})`;
      checkFn = (d: Date) => d >= start && d <= end;
    }

    return {
      periodLabel: label,
      isDateInRange: checkFn,
    };
  }, [filterPeriod, customStartDate, customEndDate, t, numberFormat]);

  // ----------------------------------------------------
  // Filtered Transactions for the Selected Period
  // ----------------------------------------------------
  const periodTransactions = useMemo(() => {
    return allTransactions.filter((tx) => {
      const d = new Date(tx.date);
      if (isNaN(d.getTime())) return filterPeriod === 'all';
      return isDateInRange(d);
    });
  }, [allTransactions, isDateInRange, filterPeriod]);

  // ----------------------------------------------------
  // Grouping by Debtor
  // ----------------------------------------------------
  const debtorGroups = useMemo<DebtorGroupSummary[]>(() => {
    const debtorMap = new Map<number, DebtorGroupSummary>();

    // Pre-populate with all filtered debtors to guarantee accurate outstanding balances
    for (let i = 0; i < filteredDebtorsByCategory.length; i++) {
      const d = filteredDebtorsByCategory[i];
      if (!d) continue;
      debtorMap.set(d.id, {
        debtorId: d.id,
        debtorName: d.name || '',
        debtorPhone: d.phone || '',
        debtorType: d.type || 'debtor',
        currentTotalDebt: Number(d.amount) || 0,
        periodAdded: 0,
        periodPaid: 0,
        periodNet: 0,
        addsCount: 0,
        paysCount: 0,
        transactions: [],
      });
    }

    // Index debtors involved in period transactions
    for (let i = 0; i < periodTransactions.length; i++) {
      const tx = periodTransactions[i];
      if (!tx) continue;
      let group = debtorMap.get(tx.debtorId);
      if (!group) {
        group = {
          debtorId: tx.debtorId,
          debtorName: tx.debtorName || '',
          debtorPhone: tx.debtorPhone || '',
          debtorType: tx.debtorType || 'debtor',
          currentTotalDebt: 0,
          periodAdded: 0,
          periodPaid: 0,
          periodNet: 0,
          addsCount: 0,
          paysCount: 0,
          transactions: [],
        };
        debtorMap.set(tx.debtorId, group);
      }

      group.transactions.push(tx);
      if (tx.type === 'add') {
        group.periodAdded += tx.amount || 0;
        group.addsCount += 1;
      } else if (tx.type === 'pay') {
        group.periodPaid += tx.amount || 0;
        group.paysCount += 1;
      }
      group.periodNet = group.periodPaid - group.periodAdded;
    }

    // Convert map to array and sort debtors
    const list = Array.from(debtorMap.values());
    return list.sort((a, b) => {
      if (b.transactions.length !== a.transactions.length) {
        return b.transactions.length - a.transactions.length;
      }
      const nameA = a?.debtorName || '';
      const nameB = b?.debtorName || '';
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
    });
  }, [periodTransactions, filteredDebtorsByCategory]);

  // ----------------------------------------------------
  // Dynamic Period Aggregates
  // ----------------------------------------------------
  const {
    periodAdded,
    periodPaid,
    periodNetMovement,
    periodDebtorsInvolved,
    periodAddsCount,
    periodPaysCount,
  } = useMemo(() => {
    let added = 0;
    let paid = 0;
    let addsCount = 0;
    let paysCount = 0;
    const debtorIdSet = new Set<number>();

    if (filterPeriod === 'all' && stats) {
      const sumTxAdded = periodTransactions.filter((t) => t.type === 'add').reduce((s, t) => s + t.amount, 0);
      const sumTxPaid = periodTransactions.filter((t) => t.type === 'pay').reduce((s, t) => s + t.amount, 0);
      
      let currentActiveDebts = 0;
      const len = filteredDebtorsByCategory.length;
      for (let i = 0; i < len; i++) {
        currentActiveDebts += Number(filteredDebtorsByCategory[i]?.amount) || 0;
      }

      paid = Math.max(stats.totalPaid || 0, sumTxPaid);
      added = Math.max(stats.totalAdded || 0, currentActiveDebts + paid, sumTxAdded);
      
      addsCount = periodTransactions.filter((t) => t.type === 'add').length;
      paysCount = periodTransactions.filter((t) => t.type === 'pay').length;
    } else {
      periodTransactions.forEach((tx) => {
        debtorIdSet.add(tx.debtorId);
        if (tx.type === 'add') {
          added += tx.amount;
          addsCount++;
        } else if (tx.type === 'pay') {
          paid += tx.amount;
          paysCount++;
        }
      });
    }

    const net = paid - added;

    return {
      periodAdded: added,
      periodPaid: paid,
      periodNetMovement: net,
      periodDebtorsInvolved: filterPeriod === 'all' ? filteredDebtorsByCategory.length : debtorIdSet.size,
      periodAddsCount: addsCount,
      periodPaysCount: paysCount,
    };
  }, [periodTransactions, filterPeriod, stats, filteredDebtorsByCategory]);

  const currentTotalDebts = useMemo(() => {
    if (filteredDebtorsByCategory.length === 0) return 0;
    let sum = 0;
    const len = filteredDebtorsByCategory.length;
    for (let i = 0; i < len; i++) {
      sum += Number(filteredDebtorsByCategory[i]?.amount) || 0;
    }
    return sum;
  }, [filteredDebtorsByCategory]);

  const collectionRate = periodAdded > 0 ? (periodPaid / periodAdded) * 100 : 0;
  const collectionRateFormatted = formatNumber(Math.round(collectionRate), numberFormat);

  // ----------------------------------------------------
  // Filtered Debtor Groups
  // ----------------------------------------------------
  const displayedDebtorGroups = useMemo(() => {
    return debtorGroups
      .map((group) => {
        let filteredTxs = group.transactions;
        if (txTypeFilter !== 'all') {
          filteredTxs = filteredTxs.filter((t) => t.type === txTypeFilter);
        }

        if (txSearchTerm.trim()) {
          const query = txSearchTerm.trim().toLowerCase();
          const matchName = group.debtorName.toLowerCase().includes(query);
          const matchPhone = (group.debtorPhone || '').includes(query);
          const matchTxs = filteredTxs.filter((t) => {
            const noteMatch = (t.notes || t.description || '').toLowerCase().includes(query);
            const amtMatch = String(t.amount).includes(query);
            return noteMatch || amtMatch;
          });

          if (!matchName && !matchPhone && matchTxs.length === 0) {
            return null;
          }

          if (!matchName && !matchPhone) {
            filteredTxs = matchTxs;
          }
        }

        if (filteredTxs.length === 0 && txTypeFilter !== 'all') {
          return null;
        }

        if (filteredTxs.length === 0 && !txSearchTerm.trim() && filterPeriod !== 'all') {
          return null;
        }

        return {
          ...group,
          transactions: filteredTxs,
        };
      })
      .filter((g): g is DebtorGroupSummary => g !== null);
  }, [debtorGroups, txTypeFilter, txSearchTerm, filterPeriod]);

  // All visible debtor IDs for quick expand all
  const visibleDebtorIds = useMemo(
    () => displayedDebtorGroups.map((g) => g.debtorId),
    [displayedDebtorGroups]
  );

  // ----------------------------------------------------
  // Share & Copy Text Report
  // ----------------------------------------------------
  const generateReportText = () => {
    const branch = getUserBranchDisplayName(currentUser, t);

    let text = `*${t('reports.financialReport', 'تقرير الحركة المالية وسجل المدينين')}*\n`;
    text += `*${t('reports.branch', 'الفرع')}:* ${branch}\n`;
    text += `*${t('reports.user', 'المستخدم')}:* ${getUserDisplayName(currentUser, t)}\n`;
    text += `*${t('reports.period', 'الفترة')}:* ${periodLabel}\n`;
    text += `*${t('reports.exportDate', 'تاريخ الاستخراج')}:* ${formatDateDigits(new Date().toISOString().split('T')[0], numberFormat)}\n`;
    text += `------------------------------------\n`;
    text += `*${t('reports.totalDebtsAdded', 'إجمالي الديون المضافة للفترة')}:* ${formatNumber(periodAdded, numberFormat)} ${currency} (${formatNumber(periodAddsCount, numberFormat)} ${t('reports.operations', 'عملية')})\n`;
    text += `*${t('reports.totalAmountsPaid', 'إجمالي المبالغ المسددة للفترة')}:* ${formatNumber(periodPaid, numberFormat)} ${currency} (${formatNumber(periodPaysCount, numberFormat)} ${t('reports.operations', 'عملية')})\n`;
    
    if (periodNetMovement > 0) {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* +${formatNumber(periodNetMovement, numberFormat)} ${currency}\n`;
    } else if (periodNetMovement < 0) {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* ${formatNumber(periodNetMovement, numberFormat)} ${currency}\n`;
    } else {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* 0 ${currency}\n`;
    }

    text += `*${t('reports.currentActiveDebts', 'إجمالي الديون القائمة حالياً')}:* ${formatNumber(currentTotalDebts, numberFormat)} ${currency}\n`;
    text += `*${t('reports.activeDebtorsInPeriod', 'المدينين المتفاعلين في الفترة')}:* ${formatNumber(periodDebtorsInvolved, numberFormat)}\n`;
    text += `------------------------------------\n`;

    const activeGroups = displayedDebtorGroups.filter((g) => g.transactions.length > 0);
    if (activeGroups.length > 0) {
      text += `*${t('reports.detailsByDebtor', 'تفاصيل وسجل العمليات حسب المدينين')} (${formatNumber(activeGroups.length, numberFormat)}):*\n\n`;
      activeGroups.forEach((g, gIdx) => {
        text += `${formatNumber(gIdx + 1, numberFormat)}) *${g.debtorName}*`;
        if (g.debtorPhone) text += ` (${formatDateDigits(g.debtorPhone, numberFormat)})`;
        text += `\n`;
        text += `   • ${t('reports.outstandingBalance', 'الرصيد القائم')}: ${formatNumber(g.currentTotalDebt, numberFormat)} ${currency}\n`;
        text += `   • ${t('reports.debtsAdded', 'ديون أضيفت')}: +${formatNumber(g.periodAdded, numberFormat)} ${currency} (${formatNumber(g.addsCount, numberFormat)})\n`;
        text += `   • ${t('reports.debtsPaid', 'مسددات')}: -${formatNumber(g.periodPaid, numberFormat)} ${currency} (${formatNumber(g.paysCount, numberFormat)})\n`;
        
        if (g.transactions.length > 0) {
          text += `   • ${t('reports.transactionsLog', 'سجل الحركات')}:\n`;
          g.transactions.slice(0, 5).forEach((tx) => {
            const sym = tx.type === 'pay' ? `[${t('reports.payment', 'سداد')}]` : `[${t('reports.debt', 'دين')}]`;
            text += `     - ${sym}: ${formatNumber(tx.amount, numberFormat)} ${currency} (${formatDateDigits(tx.date, numberFormat)})\n`;
            if (tx.notes) text += `       ${t('reports.note', 'ملاحظة')}: ${tx.notes}\n`;
          });
          if (g.transactions.length > 5) {
            text += `     - ... ${t('reports.andMoreTransactions', 'وحركات أخرى')} (${formatNumber(g.transactions.length - 5, numberFormat)})\n`;
          }
        }
        text += `\n`;
      });
    } else {
      text += `${t('reports.noTransactionsInPeriod', 'لا توجد حركات مسجلة خلال هذه الفترة.')}\n`;
    }

    text += `------------------------------------\n`;
    text += `${t('common.appName', 'دفتر الديون')}`;
    return text;
  };

  const handleExportPdf = () => {
    const branchName = getUserBranchDisplayName(currentUser, t);
    const userName = getUserDisplayName(currentUser, t);

    let statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
      <div style="background: #eff6ff; border: 1px solid #bfdbfe; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #1e3a8a; font-weight: 700;">إجمالي الديون القائمة للزبائن</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #1d4ed8;">${formatNumber(currentTotalDebts, numberFormat)} ${currency}</div>
      </div>
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #14532d; font-weight: 700;">المبالغ المسددة للفترة</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #15803d;">${formatNumber(periodPaid, numberFormat)} ${currency}</div>
      </div>
      <div style="background: #fef2f2; border: 1px solid #fecdd3; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #881337; font-weight: 700;">الديون الجديدة المضافة للفترة</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #be123c;">${formatNumber(periodAdded, numberFormat)} ${currency}</div>
      </div>
    </div>`;

    let htmlSections = '';
    const sortedGroups = [...displayedDebtorGroups]
      .filter((g) => g.transactions.length > 0 || g.currentTotalDebt > 0)
      .sort((a, b) => b.currentTotalDebt - a.currentTotalDebt);

    if (sortedGroups.length === 0) {
      htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b;">لا يوجد مدينين مطابقين للبحث والفترة المحددة</div>';
    } else {
      sortedGroups.forEach((g) => {
        let txRows = '';
        if (g.transactions.length === 0) {
          txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:8px;">لا توجد حركات تسديد أو إضافة مسجلة خلال هذه الفترة</td></tr>`;
        } else {
          g.transactions.forEach((tx, idx) => {
            const isPay = tx.type === 'pay';
            const typeLabel = isPay ? 'سداد دفعة' : 'دين جديد';
            const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
            const amountPrefix = isPay ? '-' : '+';
            const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';
            txRows += `<tr>
              <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
              <td><span class="${typeClass}">${typeLabel}</span></td>
              <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} ${currency}</strong></td>
              <td>${cleanDate}</td>
              <td>${tx.notes || tx.description || '-'}</td>
            </tr>`;
          });
        }

        htmlSections += `<div class="person-card">
          <div class="person-card-header">
            <div>
              <div class="person-name">${g.debtorName}</div>
              <div class="person-phone">رقم الهاتف: ${g.debtorPhone ? formatDateDigits(g.debtorPhone, numberFormat) : 'غير محدد'}</div>
            </div>
            <div class="person-amount-box">
              <span class="amount-value">${formatNumber(g.currentTotalDebt, numberFormat)} ${currency}</span>
              <span class="amount-label">الرصيد المتبقي</span>
            </div>
          </div>
          <div style="padding: 8px 12px; background: #fff;">
            <table class="tx-table">
              <thead>
                <tr>
                  <th style="width: 25px;">#</th>
                  <th style="width: 100px;">نوع الحركة</th>
                  <th style="width: 110px;">المبلغ</th>
                  <th style="width: 95px;">التاريخ</th>
                  <th>الملاحظات والتفاصيل</th>
                </tr>
              </thead>
              <tbody>
                ${txRows}
              </tbody>
            </table>
          </div>
        </div>`;
      });
    }

    printSystemPdfReport(
      {
        title: 'تقرير دفتر الديون والمدينين التفصيلي',
        subtitle: `إجمالي المدينين المتفاعلين: ${formatNumber(sortedGroups.length, numberFormat)} مدين | الفترة: ${periodLabel}`,
        branchName,
        userName,
        statsSummaryHtml,
        accentColor: 'blue',
      },
      htmlSections
    );
  };

  const handleShareWhatsApp = () => {
    const reportText = generateReportText();
    const url = `https://wa.me/?text=${encodeURIComponent(reportText)}`;
    window.open(url, '_blank');
  };

  const handleShareTextReport = async () => {
    try {
      const historyMap = currentUser ? getLocalDebtorHistory(currentUser.id) : {};
      const branchName = getUserBranchDisplayName(currentUser, t);
      const userName = getUserDisplayName(currentUser, t);
      const text = generateDebtorsTextReport(debtors, historyMap, {
        branchName,
        userName,
        currencySymbol: currency,
      });
      const dateStr = new Date().toISOString().slice(0, 10);
      const res = await shareTextFile(text, `تقرير_المدينين_${dateStr}.txt`, 'تقرير ديون العملاء التفصيلي');
      if (onShowToast) {
        if (res.method === 'download_fallback') {
          onShowToast('تم تنزيل الملف النصي (.txt) لعدم دعم المشاركة المباشرة في المتصفح', 'info');
        } else {
          onShowToast('تم فتح نافذة المشاركة بنجاح', 'success');
        }
      }
    } catch (err: any) {
      console.error('Error sharing text report:', err);
      if (onShowToast) {
        onShowToast('حدث خطأ أثناء مشاركة الملف النصي', 'error');
      }
    }
  };

  const handleCopyReport = async () => {
    try {
      const reportText = generateReportText();
      await navigator.clipboard.writeText(reportText);
      setCopiedReport(true);
      if (onShowToast) {
        onShowToast(t('reports.reportCopiedSuccess', 'تم نسخ التقرير المالي بنجاح'), 'success');
      }
      setTimeout(() => setCopiedReport(false), 2500);
    } catch {
      if (onShowToast) {
        onShowToast(t('reports.copyFailed', 'تعذر النسخ تلقائياً، يرجى المحاولة يدوياً'), 'error');
      }
    }
  };

  return (
    <div id="tab-reports" className="pb-40 space-y-3.5 animate-in fade-in duration-150">
      {/* ---------------------------------------------------- */}
      {/* 1. Header - Sticky */}
      {/* ---------------------------------------------------- */}
      <div className="sticky top-0 z-30 bg-slate-50 px-4 safe-top pb-2.5 border-b border-slate-200 gpu-layer">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {reportMode === 'creditors'
                  ? 'تقارير ديون عليّ'
                  : reportMode === 'suppliers'
                  ? 'تقارير الموردين والشركات'
                  : reportMode === 'debts'
                  ? t('reports.debtsAndOpsReports', 'تقارير الديون والعمليات')
                  : t('reports.installmentsReports', 'تقارير الأقساط الشهرية')}
              </h1>

              {/* DROPDOWN FILTER FOR REPORTS (ONLY IF CAN SWITCH) */}
              {canSwitchModules && (
                <div className="relative" ref={dropdownRef}>
                  <button
                    type="button"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="px-2.5 py-1 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 shadow-xs text-xs font-black text-slate-800 flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span className={`w-2 h-2 rounded-full ${
                      reportMode === 'creditors' ? 'bg-rose-600' : reportMode === 'suppliers' ? 'bg-amber-600' : reportMode === 'debts' ? 'bg-blue-600' : 'bg-emerald-600'
                    }`}></span>
                    <span>
                      {reportMode === 'creditors'
                        ? 'ديون عليّ'
                        : reportMode === 'suppliers'
                        ? 'الموردين'
                        : reportMode === 'debts'
                        ? t('reports.debtBook', 'دفتر الديون')
                        : t('reports.installmentsSystem', 'نظام الأقساط')}
                    </span>
                    <i className="fa-solid fa-chevron-down text-[9px] text-slate-400"></i>
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute top-full start-0 mt-1 w-48 bg-white border border-slate-200 rounded-2xl shadow-xl p-1 z-50 animate-in fade-in zoom-in-95 duration-100 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('debts');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'debts' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-users text-xs text-blue-600"></i>
                          <span>{t('reports.debtsReports', 'تقارير الديون (لك)')}</span>
                        </div>
                        {reportMode === 'debts' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('creditors');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'creditors' ? 'bg-rose-50 text-rose-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-hand-holding-dollar text-xs text-rose-600"></i>
                          <span>تقارير ديون عليّ</span>
                        </div>
                        {reportMode === 'creditors' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('installments');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'installments' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-clock-rotate-left text-xs text-emerald-600"></i>
                          <span>{t('reports.installmentsReports', 'تقارير الأقساط')}</span>
                        </div>
                        {reportMode === 'installments' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('suppliers');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'suppliers' ? 'bg-amber-50 text-amber-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-truck-field text-xs text-amber-600"></i>
                          <span>تقارير الموردين</span>
                        </div>
                        {reportMode === 'suppliers' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <p className="text-xs font-medium text-slate-500 mt-0.5">
              {getUserBranchDisplayName(currentUser, t)} • {reportMode === 'creditors' ? 'تحليل حركة الديون والالتزامات المالية المستحقة عليك' : reportMode === 'suppliers' ? 'تحليل حركة حسابات ديون الموردين والشركات' : reportMode === 'debts' ? t('reports.debtorOperationsLog', 'سجل العمليات المنسدل لكل مدين') : t('reports.collectionTrackingContracts', 'تحصيل ومتابعة عقود الأقساط')}
            </p>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-3.5">
        {/* Render separate sub-report based on reportMode */}
        {reportMode === 'creditors' ? (
          <CreditorsReport
            debtors={debtors}
            currentUser={currentUser}
            onShowToast={onShowToast}
          />
        ) : reportMode === 'suppliers' ? (
          <SuppliersReport
            suppliers={suppliers}
            currentUser={currentUser}
            onShowToast={onShowToast}
          />
        ) : reportMode === 'installments' ? (
          <InstallmentsReport
            installments={installments}
            currentUser={currentUser}
            onShowToast={onShowToast}
          />
        ) : (
          <>
        {/* ---------------------------------------------------- */}
        {/* 2. شريط خيارات الفلترة السريعة والتصنيف */}
        {/* ---------------------------------------------------- */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap pb-1 border-b border-slate-100 dark:border-slate-800/80">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
              <i className="fa-solid fa-calendar-days text-blue-600"></i>
              <span>{t('reports.selectTimePeriod', 'تحديد الفترة الزمنية للتقرير:')}</span>
            </div>

            {/* Segmented Period Switcher */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
              {[
                { id: 'all', label: t('reports.allPeriods', 'الكل'), icon: 'fa-layer-group' },
                { id: 'today', label: t('reports.today', 'اليوم'), icon: 'fa-calendar-day' },
                { id: 'week', label: t('reports.thisWeek', 'هذا الأسبوع'), icon: 'fa-calendar-week' },
                { id: 'month', label: t('reports.thisMonth', 'هذا الشهر'), icon: 'fa-calendar' },
                { id: 'last_month', label: t('reports.lastMonth', 'الشهر السابق'), icon: 'fa-clock-rotate-left' },
                { id: 'custom', label: t('reports.customPeriod', 'مخصصة'), icon: 'fa-calendar-days' },
              ].map((tab) => {
                const isActive = filterPeriod === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFilterPeriod(tab.id as ReportFilterPeriod)}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all shrink-0 cursor-pointer text-xs flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs font-black scale-[1.02]'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    <i className={`fa-solid ${tab.icon} text-[10px]`}></i>
                    <span className="truncate">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Date Range Selectors */}
          {filterPeriod === 'custom' && (
            <div className="p-3 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/60 dark:border-blue-900/40 grid grid-cols-1 sm:grid-cols-2 gap-2.5 animate-in fade-in duration-200">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {t('reports.fromDateStart', 'من تاريخ (بداية الفترة)')}
                </label>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold text-slate-800 dark:text-white outline-none focus:border-blue-600"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                  {t('reports.toDateEnd', 'إلى تاريخ (نهاية الفترة)')}
                </label>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono font-bold text-slate-800 dark:text-white outline-none focus:border-blue-600"
                />
              </div>
            </div>
          )}
        </div>

        {/* ---------------------------------------------------- */}
        {/* 3. بطاقات الإحصائيات المالية المحدثة للفترة */}
        {/* ---------------------------------------------------- */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {/* 1. Total Active Debts / Interactive Debtors */}
          <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-blue-950/20 flex flex-col justify-between border border-blue-500/40 relative overflow-hidden group">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-blue-100">
              <span>{t('reports.currentActiveDebts', 'الديون القائمة (لك)')}</span>
              <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
                <i className="fa-solid fa-wallet"></i>
              </div>
            </div>
            <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
              {formatNumber(currentTotalDebts, numberFormat)} <span className="text-[10.5px] font-normal text-blue-200">{currency}</span>
            </div>
            <div className="text-[10px] sm:text-[10.5px] text-blue-100 font-medium flex items-center justify-between mt-1">
              <span>{t('reports.interactionDebtorsCount', 'تفاعل')} {formatNumber(periodDebtorsInvolved, numberFormat)} {t('reports.debtorSingular', 'مدين')}</span>
              <span className="font-bold bg-white/15 px-1.5 py-0.5 rounded-md font-mono">{collectionRateFormatted}% تحصيل</span>
            </div>
          </div>

          {/* 2. Paid Debts in Period */}
          <div className="bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-emerald-950/20 flex flex-col justify-between border border-emerald-500/40 relative overflow-hidden group">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-emerald-100">
              <span>{t('reports.paidAmounts', 'المبالغ المسددة')}</span>
              <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
                <i className="fa-solid fa-circle-check"></i>
              </div>
            </div>
            <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
              {formatNumber(periodPaid, numberFormat)} <span className="text-[10.5px] font-normal text-emerald-200">{currency}</span>
            </div>
            <div className="text-[10px] sm:text-[10.5px] text-emerald-100 font-medium flex items-center gap-1 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300"></span>
              <span>{formatNumber(periodPaysCount, numberFormat)} {t('reports.collectionPayments', 'دفعة تحصيل')}</span>
            </div>
          </div>

          {/* 3. Added Debts in Period */}
          <div className="bg-gradient-to-br from-rose-600 via-rose-700 to-red-800 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-rose-950/20 flex flex-col justify-between border border-rose-500/40 relative overflow-hidden group">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-rose-100">
              <span>{t('reports.addedDebts', 'الديون المضافة')}</span>
              <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
                <i className="fa-solid fa-plus-circle"></i>
              </div>
            </div>
            <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
              {formatNumber(periodAdded, numberFormat)} <span className="text-[10.5px] font-normal text-rose-200">{currency}</span>
            </div>
            <div className="text-[10px] sm:text-[10.5px] text-rose-100 font-medium flex items-center gap-1 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-300"></span>
              <span>{formatNumber(periodAddsCount, numberFormat)} {t('reports.newAdditionOperations', 'عملية إضافة جديدة')}</span>
            </div>
          </div>

          {/* 4. Net Financial Movement in Period */}
          <div className="bg-gradient-to-br from-slate-800 via-slate-850 to-slate-900 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-slate-950/20 flex flex-col justify-between border border-slate-700/60 relative overflow-hidden group">
            <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-slate-300">
              <span>{t('reports.periodNetMovement', 'صافي حركة الفترة')}</span>
              <div className="w-7 h-7 rounded-xl bg-white/10 flex items-center justify-center text-xs shadow-inner text-amber-400">
                <i className="fa-solid fa-scale-balanced"></i>
              </div>
            </div>
            <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
              {periodNetMovement > 0 ? '+' : ''}{formatNumber(periodNetMovement, numberFormat)} <span className="text-[10.5px] font-normal text-slate-400">{currency}</span>
            </div>
            <div className="text-[10px] sm:text-[10.5px] text-slate-400 font-medium flex items-center gap-1 mt-1">
              <span className={`w-1.5 h-1.5 rounded-full ${periodNetMovement > 0 ? 'bg-emerald-400' : periodNetMovement < 0 ? 'bg-rose-400' : 'bg-slate-400'}`}></span>
              <span>
                {periodNetMovement > 0
                  ? t('reports.positiveSurplus', 'فائض تحصيل نقدي إيجابي')
                  : periodNetMovement < 0
                  ? t('reports.debtIncrease', 'زيادة في حجم الديون')
                  : t('reports.balancedMovement', 'حركة مالية متوازنة')}
              </span>
            </div>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* 4. سجل العمليات المجمع حسب كل مدين مع شريط الأدوات الموحد */}
        {/* ---------------------------------------------------- */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs overflow-hidden space-y-0">
          {/* Header & Controls */}
          <div className="p-3.5 sm:p-4 border-b border-slate-100 dark:border-slate-800 space-y-3">
            {/* Row 1: Section Title & Expand/Collapse */}
            <div className="flex items-center justify-between gap-2 flex-wrap pb-1">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center text-xs font-bold shadow-2xs">
                  <i className="fa-solid fa-users-viewfinder"></i>
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {t('reports.transactionsLogByDebtors', 'سجل العمليات حسب المدينين')} ({formatNumber(displayedDebtorGroups.length, numberFormat)} {t('reports.debtorSingular', 'مدين')})
                  </h3>
                  <p className="text-[10.5px] text-slate-400">
                    {t('reports.clickDebtorToExpand', 'اضغط على اسم أي مدين لفتح القائمة المنسدلة وعرض تفاصيل كافة عملياته')}
                  </p>
                </div>
              </div>

              {/* Expand / Collapse Controls */}
              {displayedDebtorGroups.length > 0 && (
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => expandAllDebtors(visibleDebtorIds)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 border border-slate-200/60 dark:border-slate-700"
                    title={t('reports.expandAllTitle', 'فتح كافة القوائم المنسدلة')}
                  >
                    <i className="fa-solid fa-up-right-and-down-left-from-center text-[10px] text-slate-500"></i>
                    <span>{t('reports.expandAll', 'توسيع الكل')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={collapseAllDebtors}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 border border-slate-200/60 dark:border-slate-700"
                    title={t('reports.collapseAllTitle', 'طي كافة القوائم المنسدلة')}
                  >
                    <i className="fa-solid fa-down-left-and-up-right-to-center text-[10px] text-slate-500"></i>
                    <span>{t('reports.collapseAll', 'طي الكل')}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Row 2: Search Input & Operation Type Filter */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-0.5">
              {/* Search Bar */}
              <div className="relative flex-1">
                <i className="fa-solid fa-magnifying-glass absolute start-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none"></i>
                <input
                  type="text"
                  value={txSearchTerm}
                  onChange={(e) => setTxSearchTerm(e.target.value)}
                  placeholder={t('reports.searchPlaceholder', 'البحث باسم المدين أو الملاحظة أو المبلغ...')}
                  className="w-full ps-8 pe-8 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-xl text-xs outline-none focus:border-blue-600 focus:bg-white dark:focus:bg-slate-900 text-slate-800 dark:text-white transition-all font-medium shadow-inner"
                />
                {txSearchTerm && (
                  <button
                    type="button"
                    onClick={() => setTxSearchTerm('')}
                    className="absolute end-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer text-xs"
                    title="مسح البحث"
                  >
                    <i className="fa-solid fa-xmark"></i>
                  </button>
                )}
              </div>

              {/* Type Filter Pills (All / Add / Pay) */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200/60 dark:border-slate-700 shrink-0">
                <button
                  type="button"
                  onClick={() => setTxTypeFilter('all')}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    txTypeFilter === 'all'
                      ? 'bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 font-extrabold shadow-xs border border-slate-200/60 dark:border-slate-700'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {t('reports.allFilter', 'الكل')}
                </button>
                <button
                  type="button"
                  onClick={() => setTxTypeFilter('pay')}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    txTypeFilter === 'pay'
                      ? 'bg-emerald-600 text-white font-extrabold shadow-xs'
                      : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                  }`}
                >
                  {t('reports.settlements', 'تسديدات')} ({formatNumber(periodPaysCount, numberFormat)})
                </button>
                <button
                  type="button"
                  onClick={() => setTxTypeFilter('add')}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    txTypeFilter === 'add'
                      ? 'bg-rose-600 text-white font-extrabold shadow-xs'
                      : 'text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                  }`}
                >
                  {t('reports.debts', 'ديون')} ({formatNumber(periodAddsCount, numberFormat)})
                </button>
              </div>
            </div>

            {/* Row 3: Unified Export & Share Toolbar */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-end gap-1.5 flex-wrap">
              {/* Copy Report */}
              <button
                type="button"
                onClick={handleCopyReport}
                className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-slate-200/60 dark:border-slate-700 active:scale-95"
                title="نسخ نص التقرير المالي إلى الحافظة"
              >
                <i className="fa-solid fa-copy text-xs text-slate-500"></i>
                <span>{copiedReport ? 'تم النسخ!' : 'نسخ التقرير'}</span>
              </button>

              {/* Share Text File */}
              <button
                type="button"
                onClick={handleShareTextReport}
                className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                title="مشاركة التقرير كملف نصي (.txt)"
              >
                <i className="fa-solid fa-share-nodes text-xs"></i>
                <span>مشاركة ملف (.txt)</span>
              </button>

              {/* Export PDF (Primary Action) */}
              <button
                type="button"
                onClick={handleExportPdf}
                className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 via-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-950/20 transition-all cursor-pointer active:scale-95 shrink-0"
                title="تصدير تقرير الديون التفصيلي الكامل بصيغة PDF"
              >
                <i className="fa-solid fa-file-pdf text-sm"></i>
                <span>PDF كامل</span>
              </button>
            </div>
          </div>

          {/* Debtor Accordion List (كل اسم يظهر مرة واحدة وتنسدل تحته كافة العمليات) */}
          {displayedDebtorGroups.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-base">
                <i className="fa-solid fa-users-slash"></i>
              </div>
              <div className="text-xs font-bold text-slate-700">
                {t('reports.noMatchingTransactions', 'لا توجد حركات مطابقة في هذه الفترة')}
              </div>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                {txSearchTerm
                  ? t('reports.tryAnotherSearch', 'جرب البحث بكلمة أخرى أو اختيار فترة زمنية مختلفة')
                  : t('reports.noOpsRecordedInPeriod', 'لم تسجل أي عمليات دين أو تسديد في النطاق الزمني المحدد')}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {displayedDebtorGroups.slice(0, visibleGroupsLimit).map((group) => {
                const isExpanded = expandedDebtorIds.has(group.debtorId);
                const hasTransactions = group.transactions.length > 0;

                return (
                  <div key={group.debtorId} className="transition-colors">
                    {/* Debtor Header Row (Clickable Accordion Trigger) */}
                    <div
                      onClick={() => toggleDebtorExpanded(group.debtorId)}
                      className={`p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none transition-all ${
                        isExpanded
                          ? 'bg-purple-50/60 hover:bg-purple-50'
                          : 'hover:bg-slate-50/80 active:bg-slate-100'
                      }`}
                    >
                      {/* Debtor Avatar + Name + Phone + Badge */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-10 h-10 rounded-2xl flex items-center justify-center text-sm font-black shrink-0 transition-transform ${
                            isExpanded
                              ? 'bg-purple-600 text-white shadow-xs scale-105'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {group.debtorName.charAt(0)}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                              {group.debtorName}
                            </span>

                            {group.debtorType === 'creditor' && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200 flex items-center gap-1">
                                <i className="fa-solid fa-hand-holding-dollar text-[9px]"></i>
                                <span>دين عليّ (يطلبني)</span>
                              </span>
                            )}

                            {/* Badge: Number of Transactions in Period */}
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                hasTransactions
                                  ? 'bg-slate-100 text-slate-800 border border-slate-200/60'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {hasTransactions
                                ? `${formatNumber(group.transactions.length, numberFormat)} ${t('reports.registeredOperations', 'حركات مسجلة')}`
                                : t('reports.noPeriodOperations', 'لا حركات بالفترة')}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5 flex-wrap">
                            {group.debtorPhone && (
                              <span className="font-mono text-slate-400">
                                {formatDateDigits(group.debtorPhone, numberFormat)}
                              </span>
                            )}
                            <span className="text-slate-400">•</span>
                            <span>
                              {t('reports.outstandingBalance', 'الرصيد القائم')}:{' '}
                              <strong className="text-slate-800 font-mono">
                                {formatNumber(group.currentTotalDebt, numberFormat)} {currency}
                              </strong>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Summary of Period (Added / Paid) + Accordion Toggle Icon */}
                      <div className="flex items-center gap-3 shrink-0 text-end">
                        {/* Period financial summary for this debtor */}
                        <div className="hidden sm:flex flex-col items-end text-xs font-mono">
                          {group.periodAdded > 0 && (
                            <span className="text-rose-600 font-bold">
                              +{formatNumber(group.periodAdded, numberFormat)} {currency}
                            </span>
                          )}
                          {group.periodPaid > 0 && (
                            <span className="text-emerald-600 font-bold">
                              -{formatNumber(group.periodPaid, numberFormat)} {currency}
                            </span>
                          )}
                          {group.periodAdded === 0 && group.periodPaid === 0 && (
                            <span className="text-slate-400 text-[11px]">0 {currency}</span>
                          )}
                        </div>

                        {/* Chevron Down / Up Indicator */}
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                            isExpanded
                              ? 'bg-purple-200/80 text-purple-800 rotate-180'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          <i className="fa-solid fa-chevron-down text-xs"></i>
                        </div>
                      </div>
                    </div>

                    {/* Dropdown Content: Transactions List for this Debtor */}
                    {isExpanded && (
                      <div className="bg-slate-50/70 border-t border-purple-100/80 px-3 py-2.5 sm:px-6 sm:py-3 space-y-2 animate-in fade-in duration-150">
                        {/* Debtor Quick Mini Summary Bar inside dropdown */}
                        <div className="grid grid-cols-3 gap-2 p-2 bg-white rounded-2xl border border-slate-200/70 text-center">
                          <div className="p-1">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.totalAdditions', 'إجمالي الإضافات')}</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-rose-600">
                              +{formatNumber(group.periodAdded, numberFormat)} {currency}
                            </span>
                          </div>
                          <div className="p-1 border-x border-slate-100">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.totalSettlements', 'إجمالي المسددات')}</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-emerald-600">
                              -{formatNumber(group.periodPaid, numberFormat)} {currency}
                            </span>
                          </div>
                          <div className="p-1">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.debtorNetMovement', 'صافي حركة المدين')}</span>
                            <span
                              className={`text-xs sm:text-sm font-black font-mono ${
                                group.periodNet > 0
                                  ? 'text-emerald-600'
                                  : group.periodNet < 0
                                  ? 'text-rose-600'
                                  : 'text-slate-700'
                              }`}
                            >
                              {group.periodNet > 0 ? '+' : ''}{formatNumber(group.periodNet, numberFormat)} {currency}
                            </span>
                          </div>
                        </div>

                        {/* List of operations */}
                        {group.transactions.length === 0 ? (
                          <div className="p-4 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-100">
                            {t('reports.noOpsRecordedForDebtorInPeriod', 'لا توجد عمليات مسجلة لهذا المدين خلال فترة')} ({periodLabel})
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            <div className="text-[11px] font-bold text-slate-500 px-1 pt-1 flex items-center justify-between">
                              <span>{t('reports.opsAndPaymentsList', 'قائمة العمليات والتسديدات')} ({formatNumber(group.transactions.length, numberFormat)}):</span>
                              <span className="text-[10px] text-slate-400">{t('reports.sortedNewestFirst', 'مرتبة من الأحدث إلى الأقدم')}</span>
                            </div>

                            <div className="divide-y divide-slate-100 bg-white rounded-2xl border border-slate-200/80 overflow-hidden">
                              {group.transactions.map((tx, txIdx) => {
                                const isPay = tx.type === 'pay';
                                return (
                                  <div
                                    key={tx.id || `${group.debtorId}_${txIdx}`}
                                    className="p-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-2"
                                  >
                                    {/* Operation Type Icon & Details */}
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div
                                        className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                                          isPay
                                            ? 'bg-emerald-50 text-emerald-600'
                                            : 'bg-rose-50 text-rose-600'
                                        }`}
                                      >
                                        <i className={`fa-solid ${isPay ? 'fa-arrow-down' : 'fa-arrow-up'}`}></i>
                                      </div>

                                      <div className="min-w-0">
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <span
                                            className={`text-[10.5px] font-bold px-1.5 py-0.5 rounded-md ${
                                              isPay
                                                ? 'bg-emerald-50 text-emerald-700'
                                                : 'bg-rose-50 text-rose-700'
                                            }`}
                                          >
                                            {isPay ? t('reports.paySettlement', 'تسديد دفعة') : t('reports.addDebt', 'إضافة دين')}
                                          </span>
                                          <span className="text-[10.5px] text-slate-500 font-mono flex items-center gap-1">
                                            <i className="fa-regular fa-clock text-[9px] text-slate-400"></i>
                                            <span>{formatFullDateTime(tx.date, numberFormat)}</span>
                                          </span>
                                        </div>

                                        {/* Notes if present */}
                                        {(tx.notes || (tx.description && tx.description !== 'إضافة دين جديد' && tx.description !== 'تسديد دفعة نقدية')) && (
                                          <div className="text-[10.5px] text-slate-600 mt-1 flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200/50 w-fit">
                                            <i className="fa-solid fa-note-sticky text-amber-500 text-[10px]"></i>
                                            <span className="truncate max-w-[220px] sm:max-w-md">{tx.notes || tx.description}</span>
                                          </div>
                                        )}
                                      </div>
                                    </div>

                                    {/* Amount & Balance After */}
                                    <div className="text-end shrink-0 font-mono">
                                      <div
                                        className={`text-xs sm:text-sm font-black ${
                                          isPay ? 'text-emerald-600' : 'text-rose-600'
                                        }`}
                                      >
                                        {isPay ? '-' : '+'}{formatNumber(tx.amount, numberFormat)}{' '}
                                        <span className="text-[10px] font-bold">{currency}</span>
                                      </div>
                                      <div className="text-[10px] text-slate-400">
                                        {t('reports.balanceAfter', 'الرصيد بعد')}: {formatNumber(tx.balanceAfter, numberFormat)} {currency}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Load More Button if more items exist */}
          {displayedDebtorGroups.length > visibleGroupsLimit && (
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
              <button
                type="button"
                onClick={() => setVisibleGroupsLimit((prev) => prev + 30)}
                className="w-full py-3 bg-white hover:bg-purple-50 text-purple-800 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 border border-purple-300 shadow-sm active:scale-[0.98]"
              >
                <i className="fa-solid fa-angles-down text-purple-600 text-xs"></i>
                <span>عرض المزيد من المدينين (+30)</span>
                <span className="text-[10.5px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-lg font-mono">
                  متبقي {displayedDebtorGroups.length - visibleGroupsLimit}
                </span>
              </button>
            </div>
          )}

          {/* Table Footer with Summary Count */}
          <div className="p-3 bg-slate-50 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
            <span>{t('reports.totalDisplayedDebtors', 'إجمالي المدينين المعروضين')}: {formatNumber(displayedDebtorGroups.length, numberFormat)}</span>
            <span className="font-mono font-bold text-slate-700">{periodLabel}</span>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* 5. زر تصفير السجل التراكمي إذا رغب المستخدم */}
        {/* ---------------------------------------------------- */}
        {onResetStats && (
          <div className="pt-2">
            <button
              type="button"
              onClick={onResetStats}
              className="w-full bg-slate-100 hover:bg-slate-200 active:scale-[0.99] text-slate-600 py-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-200/80"
            >
              <i className="fa-solid fa-arrows-rotate text-xs text-slate-500"></i>
              <span>{t('reports.resetCumulativeStats', 'تصفير سجل التقارير والإحصائيات التراكمية')}</span>
            </button>
          </div>
        )}
        </>
        )}
      </div>
    </div>
  );
});

ReportsTab.displayName = 'ReportsTab';

