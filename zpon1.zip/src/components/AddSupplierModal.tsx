import React, { useState, useMemo, useEffect } from 'react';
import { Supplier } from '../types';
import { formatAmountInput, parseFormattedNumber, getCurrentTimeStr, resolveRecordDateTime } from '../utils/formatters';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';
import { checkNameDuplicate, ExistingNameRecord } from '../utils/nameDuplicateChecker';
import { NameDuplicateAlert } from './NameDuplicateAlert';

interface AddSupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSupplier: (supplier: Omit<Supplier, 'id' | 'userId'>) => void;
  currencySymbol?: string;
  allowInvoiceUpload?: boolean;
  existingSuppliers?: Supplier[];
  onSelectExistingSupplier?: (supplier: Supplier) => void;
}

export const AddSupplierModal: React.FC<AddSupplierModalProps> = ({
  isOpen,
  onClose,
  onAddSupplier,
  currencySymbol = 'د.ع',
  allowInvoiceUpload = true,
  existingSuppliers = [],
  onSelectExistingSupplier,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [itemType, setItemType] = useState('');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [dateMode, setDateMode] = useState<'auto' | 'manual'>('auto');
  const [manualDate, setManualDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(false);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [manualTime, setManualTime] = useState(() => getCurrentTimeStr());
  const [error, setError] = useState<string | null>(null);
  const [allowDuplicateName, setAllowDuplicateName] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setName('');
      setPhone('');
      setCompanyName('');
      setItemType('');
      setAmount('');
      setNotes('');
      setInvoiceImage(undefined);
      setError(null);
      setAllowDuplicateName(false);
    }
  }, [isOpen]);

  const candidateRecords: ExistingNameRecord[] = useMemo(() => {
    return (existingSuppliers || []).map((s) => ({
      id: s.id,
      name: s.name,
      phone: s.phone,
      amount: s.amount,
      type: 'supplier',
    }));
  }, [existingSuppliers]);

  const nameCheckResult = useMemo(() => {
    return checkNameDuplicate(name, candidateRecords);
  }, [name, candidateRecords]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const numAmount = parseFormattedNumber(amount);
    
    if (!name.trim()) {
      setError('يرجى كتابة اسم المورد أولاً');
      return;
    }

    if (nameCheckResult.hasExactMatch && !allowDuplicateName) {
      setError(`يوجد مورد مسجل مسبقاً باسم "${nameCheckResult.exactMatch?.name}". يرجى فتح حسابه أو تفعيل خيار السماح بالتكرار أدناه.`);
      return;
    }

    if (!amount || !amount.trim() || isNaN(numAmount) || numAmount <= 0) {
      setError('يرجى كتابة مبلغ الدين المطلوب للمورد أولاً (يجب أن يكون أكبر من 0)');
      return;
    }

    const cleanPhone = phone.trim();
    const baseDate = dateMode === 'auto'
      ? new Date().toISOString().split('T')[0]
      : manualDate;
    const finalIsoDate = resolveRecordDateTime(baseDate, recordTime, timeMode, manualTime);

    onAddSupplier({
      name: name.trim(),
      phone: cleanPhone,
      companyName: companyName.trim() || undefined,
      itemType: itemType.trim() || undefined,
      amount: numAmount,
      status: 'active',
      notes: notes.trim() || undefined,
      createdAt: finalIsoDate,
      lastTransactionDate: finalIsoDate,
      invoiceImage,
      history: [
        {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 6),
          supplierId: 0,
          type: 'initial',
          amount: numAmount,
          balanceAfter: numAmount,
          date: finalIsoDate,
          description: 'تسجيل دين بضاعة مسبق / جديد',
          notes: notes.trim() || undefined,
          itemType: itemType.trim() || undefined,
          invoiceImage,
        },
      ],
    });

    // Reset fields & Close
    setName('');
    setPhone('');
    setCompanyName('');
    setItemType('');
    setAmount('');
    setNotes('');
    setInvoiceImage(undefined);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-orange-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-truck-field text-amber-100"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">إضافة مورد أو شركة بضاعة جديدة</h3>
              <p className="text-[11px] text-amber-100/90 font-medium">تسجيل دين عليك لصالح المورد / المصنع</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 overflow-y-auto text-start">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{error}</span>
            </div>
          )}
          {/* Supplier Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                اسم المورد / المندوب <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder=""
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
              />
              <NameDuplicateAlert
                checkResult={nameCheckResult}
                currency={currencySymbol}
                onSelectExisting={(rec) => {
                  const found = (existingSuppliers || []).find((s) => s.id === rec.id);
                  if (found && onSelectExistingSupplier) onSelectExistingSupplier(found);
                }}
                allowSameNameAnyway={allowDuplicateName}
                onToggleAllowSameName={setAllowDuplicateName}
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                رقم هاتف المورد (واتساب)
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder=""
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all text-left dir-ltr"
              />
            </div>
          </div>

          {/* Company Name */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              اسم الشركة / المعمل / المكتب
            </label>
            <input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder=""
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
            />
          </div>

          {/* Larger Item Type Field */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              تفاصيل ونوع البضاعة / المواد
            </label>
            <textarea
              rows={2}
              value={itemType}
              onChange={(e) => setItemType(e.target.value)}
              placeholder=""
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Amount Field */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              المبلغ المطلوب للمورد (الذمة القائمة عليك) <span className="text-rose-500">*</span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={amount}
                onChange={(e) => setAmount(formatAmountInput(e.target.value))}
                placeholder="0"
                className="w-full p-3 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800/80 rounded-2xl text-sm font-extrabold text-amber-900 dark:text-amber-200 outline-none focus:border-amber-600 focus:ring-2 focus:ring-amber-500/30 transition-all"
              />
              <span className="absolute left-3 text-xs font-extrabold text-amber-700 dark:text-amber-400">
                {currencySymbol}
              </span>
            </div>
          </div>

          {/* Date Selector: Auto vs Manual */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <i className="fa-regular fa-calendar-days text-amber-600"></i>
                <span>تاريخ تسجيل المورد والدين:</span>
              </label>

              <div className="flex items-center gap-1 bg-slate-200/80 dark:bg-slate-700/80 p-0.5 rounded-xl text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setDateMode('auto')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    dateMode === 'auto'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  تلقائي (اليوم)
                </button>
                <button
                  type="button"
                  onClick={() => setDateMode('manual')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    dateMode === 'manual'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  يدوي (تاريخ محدد)
                </button>
              </div>
            </div>

            {dateMode === 'manual' ? (
              <div className="mt-1">
                <input
                  type="date"
                  required
                  value={manualDate}
                  onChange={(e) => setManualDate(e.target.value)}
                  className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 font-mono"
                />
              </div>
            ) : (
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                تاريخ التسجيل: <span className="font-bold text-amber-700 dark:text-amber-400">{new Date().toISOString().split('T')[0]}</span>
              </p>
            )}
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={manualTime}
            onTimeChange={setManualTime}
            accentColor="amber"
            idPrefix="add_sup"
          />

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              ملاحظات أو تفاصيل الفاتورة/الوصل
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder=""
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none"
            />
          </div>

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label="صورة فاتورة / قائمة الشراء الأولى (اختياري)"
          />

          {/* Submit Button */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2.5 pb-[max(0.75rem,calc(env(safe-area-inset-bottom)+0.25rem))]">
            <button
              type="submit"
              className="flex-1 min-h-[48px] py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 active:from-amber-800 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-2 touch-manipulation"
            >
              <i className="fa-solid fa-check text-xs"></i>
              <span>حفظ المورد</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[48px] py-3 px-5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs sm:text-sm transition-all cursor-pointer active:scale-[0.98] touch-manipulation border border-slate-200/50 dark:border-slate-700/50"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
