import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType?: string;
  createdTime?: string;
  modifiedTime?: string;
  size?: string;
  description?: string;
  webViewLink?: string;
}

export interface GoogleDriveUser {
  uid?: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

export type CachedGoogleUser = GoogleDriveUser;

export const GOOGLE_DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
];

const STORAGE_TOKEN_KEY = 'aldion_gdrive_oauth_token';
const STORAGE_USER_KEY = 'aldion_gdrive_cached_user';
const STORAGE_TIMESTAMP_KEY = 'aldion_gdrive_token_timestamp';

const loadPersistedToken = (): string | null => {
  try {
    return localStorage.getItem(STORAGE_TOKEN_KEY);
  } catch {
    return null;
  }
};

const loadPersistedUser = (): GoogleDriveUser | null => {
  try {
    const raw = localStorage.getItem(STORAGE_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const persistSession = (
  user: GoogleDriveUser | null,
  token: string | null
) => {
  try {
    if (token) {
      localStorage.setItem(STORAGE_TOKEN_KEY, token);
      localStorage.setItem(STORAGE_TIMESTAMP_KEY, Date.now().toString());
    } else {
      localStorage.removeItem(STORAGE_TOKEN_KEY);
      localStorage.removeItem(STORAGE_TIMESTAMP_KEY);
    }

    if (user) {
      const data: GoogleDriveUser = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      };
      localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(data));
    } else {
      localStorage.removeItem(STORAGE_USER_KEY);
    }
  } catch (e) {
    console.warn('Failed to persist Google Drive session:', e);
  }
};

export const clearPersistedSession = () => {
  cachedAccessToken = null;
  cachedUser = null;
  persistSession(null, null);
};

// In-memory cache synced with localStorage
let cachedAccessToken: string | null = loadPersistedToken();
let cachedUser: GoogleDriveUser | null = loadPersistedUser();
let isSigningIn = false;

// Initialize Firebase app and auth as backup provider
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
GOOGLE_DRIVE_SCOPES.forEach((scope) => provider.addScope(scope));
provider.setCustomParameters({
  prompt: 'select_account',
});

type AuthCallback = (
  user: GoogleDriveUser | null,
  token: string | null
) => void;

const authListeners = new Set<AuthCallback>();

const notifyAuthListeners = (
  user: GoogleDriveUser | null,
  token: string | null
) => {
  authListeners.forEach((cb) => {
    try {
      cb(user, token);
    } catch (e) {
      console.warn('Auth listener notification failed:', e);
    }
  });
};

/**
 * Dynamically loads Google Identity Services (GIS) library if not already present.
 */
const loadGsiScript = (): Promise<void> => {
  if (typeof window === 'undefined') return Promise.resolve();
  if ((window as any).google?.accounts?.oauth2) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const existing = document.getElementById('google-gsi-client');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', (e) => reject(e));
      return;
    }
    const script = document.createElement('script');
    script.id = 'google-gsi-client';
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = (e) => reject(e);
    document.head.appendChild(script);
  });
};

/**
 * Fetches user profile directly from Google OAuth UserInfo API without Firebase.
 */
export const fetchGoogleUserInfo = async (
  accessToken: string
): Promise<GoogleDriveUser> => {
  const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    throw new Error('فشل استرداد بيانات الحساب من Google');
  }
  const data = await res.json();
  return {
    uid: data.sub,
    email: data.email || null,
    displayName: data.name || data.given_name || 'حساب Google',
    photoURL: data.picture || null,
  };
};

/**
 * Direct Google OAuth sign-in via official Google Identity Services (GIS).
 */
const signInWithGis = async (
  clientId: string
): Promise<{ user: GoogleDriveUser; accessToken: string }> => {
  await loadGsiScript();
  const google = (window as any).google;
  if (!google?.accounts?.oauth2) {
    throw new Error('Google Identity Services غير متاح');
  }

  return new Promise((resolve, reject) => {
    try {
      const tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: GOOGLE_DRIVE_SCOPES.join(' ') + ' https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email',
        prompt: 'select_account',
        callback: async (resp: any) => {
          if (resp.error) {
            reject(new Error(resp.error_description || resp.error));
            return;
          }
          if (!resp.access_token) {
            reject(new Error('لم يتم استلام رمز الوصول (Access Token) من Google'));
            return;
          }
          try {
            const user = await fetchGoogleUserInfo(resp.access_token);
            resolve({ user, accessToken: resp.access_token });
          } catch {
            resolve({
              user: { uid: 'google-user', email: null, displayName: 'حساب Google', photoURL: null },
              accessToken: resp.access_token,
            });
          }
        },
        error_callback: (err: any) => {
          reject(new Error(err?.message || 'فشل فتح نافذة تسجيل الدخول بـ Google'));
        },
      });

      tokenClient.requestAccessToken({ prompt: 'select_account' });
    } catch (e: any) {
      reject(e);
    }
  });
};

/**
 * Initializes Google Auth state listener and notifies immediately from persistent storage.
 */
export const initDriveAuth = (
  onAuthChange: (
    user: GoogleDriveUser | null,
    token: string | null
  ) => void
) => {
  authListeners.add(onAuthChange);

  // 1. Immediately invoke listener with persisted session to avoid login flash on page reload/reopen
  const initialToken = getDriveAccessToken();
  const initialUser = getDriveUser();
  if (initialToken && initialUser) {
    onAuthChange(initialUser, initialToken);
  }

  // 2. Also listen to fallback provider changes to keep session updated
  const unsubscribeFirebase = onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    const currentToken = getDriveAccessToken();
    if (user) {
      const gUser: GoogleDriveUser = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      };
      cachedUser = gUser;
      persistSession(gUser, currentToken);
      onAuthChange(gUser, currentToken);
    } else if (currentToken) {
      const cached = loadPersistedUser();
      cachedUser = cached;
      onAuthChange(cached, currentToken);
    } else {
      cachedUser = null;
      onAuthChange(null, null);
    }
  });

  // 3. Check for any pending redirect auth result (for mobile/WebView redirect flow)
  getRedirectResult(auth)
    .then((result) => {
      if (result) {
        const credential = GoogleAuthProvider.credentialFromResult(result);
        if (credential?.accessToken) {
          cachedAccessToken = credential.accessToken;
          const gUser: GoogleDriveUser = {
            uid: result.user.uid,
            email: result.user.email,
            displayName: result.user.displayName,
            photoURL: result.user.photoURL,
          };
          cachedUser = gUser;
          persistSession(gUser, credential.accessToken);
          notifyAuthListeners(gUser, credential.accessToken);
        }
      }
    })
    .catch((err) => {
      console.warn('Redirect sign-in check:', err);
    });

  return () => {
    authListeners.delete(onAuthChange);
    unsubscribeFirebase();
  };
};

/**
 * Initiates direct Google OAuth Sign-in and stores the Drive OAuth Access Token.
 */
export const googleSignIn = async (): Promise<{
  user: GoogleDriveUser;
  accessToken: string;
} | null> => {
  try {
    isSigningIn = true;
    let result;
    try {
      result = await signInWithPopup(auth, provider);
    } catch (popupErr: any) {
      if (
        popupErr?.code === 'auth/popup-blocked' ||
        popupErr?.message?.includes('popup-blocked')
      ) {
        // Fallback to signInWithRedirect when popup is blocked (e.g. in some mobile WebViews)
        await signInWithRedirect(auth, provider);
        return null;
      }
      throw popupErr;
    }

    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('لم يتم استلام رمز الوصول (Access Token) من Google');
    }
    cachedAccessToken = credential.accessToken;
    cachedUser = {
      uid: result.user.uid,
      email: result.user.email,
      displayName: result.user.displayName,
      photoURL: result.user.photoURL,
    };
    persistSession(cachedUser, cachedAccessToken);
    notifyAuthListeners(cachedUser, cachedAccessToken);
    return { user: cachedUser, accessToken: cachedAccessToken };
  } catch (error: any) {
    if (
      error?.code === 'auth/popup-closed-by-user' ||
      error?.message?.includes('popup-closed-by-user') ||
      error?.message?.includes('cancelled-popup-request') ||
      error?.code === 'auth/cancelled-popup-request'
    ) {
      // User cancelled sign-in by closing popup window; handle smoothly
      return null;
    }
    if (
      error?.code === 'auth/unauthorized-domain' ||
      error?.message?.includes('unauthorized-domain')
    ) {
      const customErr: any = new Error(
        'نطاق التطبيق أو بيئة الهاتف (APK) غير مسجلة في النطاقات المصرح بها لـ Firebase.'
      );
      customErr.code = 'auth/unauthorized-domain';
      throw customErr;
    }
    console.error('Google Drive Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Signs out from Google and clears stored session.
 */
export const googleSignOut = async (): Promise<void> => {
  try {
    if (cachedAccessToken) {
      const google = (window as any).google;
      if (google?.accounts?.oauth2?.revoke) {
        try {
          google.accounts.oauth2.revoke(cachedAccessToken, () => {});
        } catch {}
      }
    }
    await signOut(auth).catch(() => {});
  } finally {
    clearPersistedSession();
    notifyAuthListeners(null, null);
  }
};

/**
 * Returns current access token (from memory or localStorage).
 */
export const getDriveAccessToken = (): string | null => {
  if (!cachedAccessToken) {
    cachedAccessToken = loadPersistedToken();
  }
  return cachedAccessToken;
};

/**
 * Sets current access token and persists it.
 */
export const setDriveAccessToken = (token: string | null) => {
  cachedAccessToken = token;
  const currentUser = getDriveUser();
  persistSession(currentUser, token);
};

/**
 * Returns current Google user (from memory or cached profile).
 */
export const getDriveUser = (): GoogleDriveUser | null => {
  if (cachedUser) return cachedUser;
  const persisted = loadPersistedUser();
  if (persisted) return persisted;
  if (auth.currentUser) {
    return {
      uid: auth.currentUser.uid,
      email: auth.currentUser.email,
      displayName: auth.currentUser.displayName,
      photoURL: auth.currentUser.photoURL,
    };
  }
  return null;
};

/**
 * Finds or creates dedicated application folder on Google Drive.
 */
export const getOrCreateBackupFolder = async (
  accessToken: string
): Promise<string> => {
  const folderName = 'نسخ_دفتر_الديون_والأقساط';
  try {
    const query = `mimeType = 'application/vnd.google-apps.folder' and name = '${folderName}' and trashed = false`;
    const listUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
      query
    )}&fields=files(id,name)`;

    const listRes = await fetch(listUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (listRes.ok) {
      const listData = await listRes.json();
      if (listData.files && listData.files.length > 0) {
        return listData.files[0].id;
      }
    } else if (listRes.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }

    // Create the folder
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder',
        description:
          'مجلد النسخ الاحتياطية لتطبيق دفتر الديون والأقساط والموردين',
      }),
    });

    if (createRes.ok) {
      const newFolder = await createRes.json();
      return newFolder.id || 'root';
    } else if (createRes.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }
  } catch (e: any) {
    if (e?.message?.includes('انتهت صلاحية')) {
      throw e;
    }
    console.warn('Could not ensure dedicated folder, fallback to root:', e);
  }
  return 'root';
};

/**
 * Uploads a complete backup payload to Google Drive using multipart upload.
 */
export const uploadBackupToGoogleDrive = async (
  accessToken: string,
  fileName: string,
  jsonString: string,
  description?: string
): Promise<GoogleDriveFile> => {
  const folderId = await getOrCreateBackupFolder(accessToken);
  const boundary = '-------aldion_drive_boundary_' + Date.now();
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description:
      description || 'نسخة احتياطية شاملة لكافة الأنظمة والصور المرفقة',
    parents: folderId && folderId !== 'root' ? [folderId] : undefined,
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    jsonString +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime,webViewLink,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!res.ok) {
    if (res.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }
    const errorText = await res.text();
    if (
      errorText.includes('storageQuotaExceeded') ||
      errorText.includes('quota has been exceeded')
    ) {
      throw new Error(
        'مساحة التخزين في حساب Google Drive الخاص بك ممتلئة تماماً (15GB). يرجى تفريغ بعض المساحة في Google Drive أو سلة المهملات، أو استخدام حساب آخر.'
      );
    }
    throw new Error(`فشل رفع النسخة الاحتياطية إلى Google Drive: ${errorText}`);
  }

  return await res.json();
};

/**
 * Lists all backup JSON files stored on Google Drive.
 */
export const listDriveBackups = async (
  accessToken: string
): Promise<GoogleDriveFile[]> => {
  const query = `(name contains 'backup_' or name contains '.json' or mimeType = 'application/json') and trashed = false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
    query
  )}&fields=files(id,name,size,createdTime,modifiedTime,webViewLink,description)&orderBy=createdTime desc&pageSize=50`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    if (res.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }
    const errText = await res.text();
    throw new Error(`تعذر استعراض النسخ من Google Drive: ${errText}`);
  }

  const data = await res.json();
  return data.files || [];
};

/**
 * Downloads the full backup payload JSON from Google Drive.
 */
export const downloadDriveBackupContent = async (
  accessToken: string,
  fileId: string
): Promise<any> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    if (res.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }
    const errText = await res.text();
    throw new Error(
      `تعذر تنزيل ملف النسخة الاحتياطية من Google Drive: ${errText}`
    );
  }

  const jsonText = await res.text();
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('الملف الذي تم تنزيله ليس بصيغة JSON صالحة');
  }
};

/**
 * Deletes a backup file from Google Drive.
 */
export const deleteDriveBackupFile = async (
  accessToken: string,
  fileId: string
): Promise<boolean> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok && res.status !== 204) {
    if (res.status === 401) {
      clearPersistedSession();
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى النقر على زر تسجيل الدخول لتجديد الاتصال.'
      );
    }
    const errText = await res.text();
    throw new Error(`تعذر حذف الملف من Google Drive: ${errText}`);
  }

  return true;
};

// ============================================================================
// AUTOMATED GOOGLE DRIVE BACKUP ENGINE (المزامنة والحفظ التلقائي في الخلفية)
// ============================================================================

const STORAGE_AUTO_BACKUP_ENABLED_KEY = 'aldion_gdrive_auto_backup_enabled';
const STORAGE_LAST_AUTO_BACKUP_TIME_KEY = 'aldion_gdrive_last_auto_backup_time';
const STORAGE_LAST_AUTO_BACKUP_SIG_KEY = 'aldion_gdrive_last_auto_backup_sig';

export type AutoBackupStatus =
  | 'idle'
  | 'syncing'
  | 'synced'
  | 'error'
  | 'disabled'
  | 'needs_auth';

export interface AutoBackupState {
  status: AutoBackupStatus;
  lastSyncTime: string | null;
  lastFileName?: string;
  error?: string | null;
}

export const isAutoDriveBackupEnabled = (): boolean => {
  try {
    const val = localStorage.getItem(STORAGE_AUTO_BACKUP_ENABLED_KEY);
    // Defaults to true when user has connected Google Drive, unless explicitly disabled
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
};

export const setAutoDriveBackupEnabled = (enabled: boolean) => {
  try {
    localStorage.setItem(STORAGE_AUTO_BACKUP_ENABLED_KEY, enabled ? 'true' : 'false');
    updateAutoBackupState({
      status: enabled ? (getDriveAccessToken() ? 'idle' : 'needs_auth') : 'disabled',
    });
  } catch (e) {
    console.warn('Could not save auto backup preference:', e);
  }
};

export const getLastAutoDriveBackupTime = (): string | null => {
  try {
    return localStorage.getItem(STORAGE_LAST_AUTO_BACKUP_TIME_KEY);
  } catch {
    return null;
  }
};

export const setLastAutoDriveBackupTime = (timeIso: string) => {
  try {
    localStorage.setItem(STORAGE_LAST_AUTO_BACKUP_TIME_KEY, timeIso);
  } catch (e) {
    console.warn('Could not save last auto backup time:', e);
  }
};

let currentAutoBackupState: AutoBackupState = {
  status: isAutoDriveBackupEnabled()
    ? (getDriveAccessToken() ? 'idle' : 'needs_auth')
    : 'disabled',
  lastSyncTime: getLastAutoDriveBackupTime(),
  error: null,
};

type AutoBackupStateListener = (state: AutoBackupState) => void;
const autoBackupListeners = new Set<AutoBackupStateListener>();

const updateAutoBackupState = (partial: Partial<AutoBackupState>) => {
  currentAutoBackupState = { ...currentAutoBackupState, ...partial };
  autoBackupListeners.forEach((listener) => {
    try {
      listener(currentAutoBackupState);
    } catch (e) {
      console.warn('Auto backup listener error:', e);
    }
  });
};

export const getAutoBackupState = (): AutoBackupState => {
  return currentAutoBackupState;
};

export const subscribeAutoBackupState = (
  listener: AutoBackupStateListener
): (() => void) => {
  autoBackupListeners.add(listener);
  // Immediate trigger with current state
  listener(currentAutoBackupState);
  return () => {
    autoBackupListeners.delete(listener);
  };
};

/**
 * Saves or updates a master automatic backup file on Google Drive.
 * If an auto-backup file with the designated name already exists in the backup folder,
 * it updates it via PATCH instead of creating duplicate files, keeping Drive clean and avoiding quota bloat.
 */
export const saveOrUpdateAutoBackupToGoogleDrive = async (
  accessToken: string,
  fileName: string,
  jsonString: string,
  description?: string
): Promise<{ file: GoogleDriveFile; action: 'updated' | 'created' }> => {
  const folderId = await getOrCreateBackupFolder(accessToken);
  const boundary = '-------aldion_auto_boundary_' + Date.now();
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  // Search if auto-backup file already exists in this folder
  let existingFileId: string | null = null;
  try {
    const sanitizedFileName = fileName.replace(/'/g, "\\'");
    let query = `name = '${sanitizedFileName}' and trashed = false`;
    if (folderId && folderId !== 'root') {
      query += ` and '${folderId}' in parents`;
    }
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)&pageSize=1`,
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );
    if (searchRes.ok) {
      const searchData = await searchRes.json();
      if (searchData.files && searchData.files.length > 0) {
        existingFileId = searchData.files[0].id;
      }
    }
  } catch (searchErr) {
    console.warn('Could not check existing auto-backup file:', searchErr);
  }

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: description || 'نسخة احتياطية تلقائية شاملة متزامنة مع Google Drive',
    ...(existingFileId ? {} : (folderId && folderId !== 'root' ? { parents: [folderId] } : {})),
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    jsonString +
    closeDelimiter;

  const url = existingFileId
    ? `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime,webViewLink,description`
    : `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime,webViewLink,description`;

  const method = existingFileId ? 'PATCH' : 'POST';

  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
    },
    body: multipartRequestBody,
  });

  if (!res.ok) {
    if (res.status === 401) {
      clearPersistedSession();
      updateAutoBackupState({ status: 'needs_auth', error: 'انتهت صلاحية جلسة Google' });
      throw new Error(
        'انتهت صلاحية جلسة Google Drive. يُرجى تسجيل الدخول لتجديد الاتصال.'
      );
    }
    const errText = await res.text();
    throw new Error(`فشل حفظ النسخة التلقائية على Google Drive: ${errText}`);
  }

  const fileData = await res.json();
  return { file: fileData, action: existingFileId ? 'updated' : 'created' };
};

// Debounce timer for background auto-sync
let autoBackupDebounceTimer: any = null;
let isAutoBackupRunning = false;

export interface AutoBackupPayloadProviderResult {
  jsonStr: string;
  fileName: string;
  signature: string;
  description?: string;
}

export type AutoBackupPayloadProvider = () => Promise<AutoBackupPayloadProviderResult | null>;

export interface ScheduleAutoDriveBackupCallbacks {
  onSyncing?: () => void;
  onSuccess?: (fileName: string) => void;
  onError?: (err: string) => void;
  onNeedsAuth?: () => void;
}

/**
 * Schedules an automated background backup to Google Drive.
 * Debounces calls by default (5 seconds) to batch multiple rapid transactions.
 */
export const scheduleAutoDriveBackup = (
  provider: AutoBackupPayloadProvider,
  delayMs: number = 5000,
  callbacks?: ScheduleAutoDriveBackupCallbacks
) => {
  if (!isAutoDriveBackupEnabled()) {
    updateAutoBackupState({ status: 'disabled' });
    return;
  }

  const token = getDriveAccessToken();
  if (!token) {
    updateAutoBackupState({ status: 'needs_auth' });
    if (callbacks?.onNeedsAuth) {
      callbacks.onNeedsAuth();
    }
    return;
  }

  // Clear previous debounce
  if (autoBackupDebounceTimer) {
    clearTimeout(autoBackupDebounceTimer);
    autoBackupDebounceTimer = null;
  }

  autoBackupDebounceTimer = setTimeout(() => {
    if (callbacks?.onSyncing) {
      callbacks.onSyncing();
    }
    executeAutoDriveBackup(provider, false)
      .then((success) => {
        if (success && callbacks?.onSuccess) {
          callbacks.onSuccess(getAutoBackupState().lastFileName || 'Google Drive');
        }
      })
      .catch((e) => {
        console.warn('Auto drive backup execution error:', e);
        if (callbacks?.onError) {
          callbacks.onError(e?.message || '');
        }
      });
  }, delayMs);
};

/**
 * Executes the auto-backup immediately (can be called manually from UI "مزامنة الآن")
 */
export const executeAutoDriveBackupNow = async (
  provider: AutoBackupPayloadProvider
): Promise<boolean> => {
  if (autoBackupDebounceTimer) {
    clearTimeout(autoBackupDebounceTimer);
    autoBackupDebounceTimer = null;
  }
  return await executeAutoDriveBackup(provider, true);
};

const executeAutoDriveBackup = async (
  provider: AutoBackupPayloadProvider,
  force: boolean = false
): Promise<boolean> => {
  if (!isAutoDriveBackupEnabled()) {
    updateAutoBackupState({ status: 'disabled' });
    return false;
  }

  const token = getDriveAccessToken();
  if (!token) {
    updateAutoBackupState({ status: 'needs_auth', error: 'الحساب غير متصل' });
    return false;
  }

  if (isAutoBackupRunning) {
    return false;
  }

  try {
    isAutoBackupRunning = true;
    updateAutoBackupState({ status: 'syncing', error: null });

    const payloadResult = await provider();
    if (!payloadResult) {
      updateAutoBackupState({ status: 'idle' });
      return false;
    }

    const { jsonStr, fileName, signature, description } = payloadResult;

    // Check if signature matches previous successful backup to avoid unnecessary network uploads
    const lastSig = localStorage.getItem(STORAGE_LAST_AUTO_BACKUP_SIG_KEY);
    if (!force && lastSig && lastSig === signature) {
      // Content has not changed since last successful backup
      updateAutoBackupState({
        status: 'synced',
        lastSyncTime: getLastAutoDriveBackupTime(),
        lastFileName: fileName,
        error: null,
      });
      return true;
    }

    const uploadRes = await saveOrUpdateAutoBackupToGoogleDrive(
      token,
      fileName,
      jsonStr,
      description
    );

    const nowIso = new Date().toISOString();
    setLastAutoDriveBackupTime(nowIso);
    try {
      localStorage.setItem(STORAGE_LAST_AUTO_BACKUP_SIG_KEY, signature);
    } catch {}

    updateAutoBackupState({
      status: 'synced',
      lastSyncTime: nowIso,
      lastFileName: uploadRes.file.name,
      error: null,
    });

    return true;
  } catch (err: any) {
    console.warn('Automated Drive backup failed:', err);
    updateAutoBackupState({
      status: err?.message?.includes('انتهت صلاحية') ? 'needs_auth' : 'error',
      error: err?.message || 'تعذر إتمام الحفظ التلقائي',
    });
    return false;
  } finally {
    isAutoBackupRunning = false;
  }
};

