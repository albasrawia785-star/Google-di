/**
 * Arabic Name Duplicate & Similarity Checker Utility
 * Prevents accidental duplicate accounts and alerts user to similar existing names
 */

export interface ExistingNameRecord {
  id: number;
  name: string;
  phone?: string;
  amount?: number;
  type?: string; // 'debtor' | 'creditor' | 'installment' | 'supplier'
}

export interface SimilarNameMatch {
  record: ExistingNameRecord;
  matchType: 'exact' | 'contains' | 'word_match' | 'fuzzy';
  message: string;
}

export interface NameCheckResult {
  hasExactMatch: boolean;
  exactMatch?: ExistingNameRecord;
  hasSimilarMatches: boolean;
  similarMatches: SimilarNameMatch[];
}

/**
 * Normalizes Arabic text for high-accuracy comparison:
 * - Strips all tashkeel (diacritics)
 * - Normalizes Alef variants (أ, إ, آ, ٱ -> ا)
 * - Normalizes Yeh variants (ى, ي, ئ -> ي)
 * - Normalizes Teh Marbuta / Heh (ة, ه -> ه)
 * - Normalizes Kaf / Waw variants
 * - Normalizes spaces and punctuation
 */
export function normalizeArabicName(text: string): string {
  if (!text) return '';
  let str = text.trim().toLowerCase();

  // Remove Arabic diacritics / tashkeel
  str = str.replace(/[\u064B-\u065F\u0670\u0617-\u061A]/g, '');

  // Normalize Alef forms
  str = str.replace(/[أإآٱ]/g, 'ا');

  // Normalize Yeh / Alef Maqsura / Hamza on Yeh
  str = str.replace(/[ىئ]/g, 'ي');

  // Normalize Teh Marbuta & Heh
  str = str.replace(/ة/g, 'ه');

  // Normalize Hamza variants
  str = str.replace(/ؤ/g, 'و');
  str = str.replace(/ء/g, '');

  // Normalize Tatweel
  str = str.replace(/ـ+/g, '');

  // Remove punctuation and extra symbols
  str = str.replace(/[.,/#!$%^&*;:{}=\-_`~()?"'«»]/g, ' ');

  // Collapse multiple whitespaces
  str = str.replace(/\s+/g, ' ').trim();

  return str;
}

/**
 * Standardizes compound Arabic names like (عبد الله -> عبدالله), (ابو فلان -> ابوفلان)
 */
export function canonicalArabicName(text: string): string {
  let str = normalizeArabicName(text);
  if (!str) return '';

  // Merge 'عبد ' with next word: (عبد الله -> عبدالله)
  str = str.replace(/\bعبد\s+([ا-ي])/g, 'عبد$1');
  // Merge 'ابو ' with next word: (ابو علي -> ابوعلي)
  str = str.replace(/\bابو\s+([ا-ي])/g, 'ابو$1');
  // Standardize 'ابن ' to 'بن '
  str = str.replace(/\bابن\s+/g, 'بن ');

  return str;
}

/**
 * Strips definite article 'ال' from a word if word length > 3
 */
function stripAlPrefix(word: string): string {
  if (word.startsWith('ال') && word.length > 3) {
    return word.slice(2);
  }
  return word;
}

/**
 * Calculates Levenshtein distance between two short strings
 */
function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;

  const d: number[][] = [];
  for (let i = 0; i <= m; i++) d[i] = [i];
  for (let j = 0; j <= n; j++) d[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(
        d[i - 1][j] + 1, // deletion
        d[i][j - 1] + 1, // insertion
        d[i - 1][j - 1] + cost // substitution
      );
    }
  }
  return d[m][n];
}

/**
 * Checks candidate name against a list of existing records
 */
export function checkNameDuplicate(
  candidateName: string,
  existingRecords: ExistingNameRecord[],
  excludeId?: number
): NameCheckResult {
  const normCandidate = normalizeArabicName(candidateName);
  const canonCandidate = canonicalArabicName(candidateName);

  const result: NameCheckResult = {
    hasExactMatch: false,
    hasSimilarMatches: false,
    similarMatches: [],
  };

  if (!normCandidate || normCandidate.length < 2) {
    return result;
  }

  const candidateWords = normCandidate.split(' ').filter((w) => w.length > 1);
  const candidateRoots = candidateWords.map(stripAlPrefix);

  for (const record of existingRecords) {
    if (excludeId !== undefined && record.id === excludeId) continue;
    const normExisting = normalizeArabicName(record.name);
    const canonExisting = canonicalArabicName(record.name);
    if (!normExisting) continue;

    // 1. Exact match after normalization or canonical compound resolution
    if (normCandidate === normExisting || canonCandidate === canonExisting) {
      result.hasExactMatch = true;
      result.exactMatch = record;
      continue;
    }

    // 2. Substring containment (e.g. "احمد علي" inside "احمد علي جواد")
    if (
      (normCandidate.length >= 3 && normExisting.includes(normCandidate)) ||
      (normExisting.length >= 3 && candidateName.length >= 3 && normCandidate.includes(normExisting))
    ) {
      result.similarMatches.push({
        record,
        matchType: 'contains',
        message: 'يحتوي على نفس مقطع الاسم',
      });
      continue;
    }

    // 3. Shared multi-word tokens (e.g. matching first 2 words or roots with/without "ال")
    const existingWords = normExisting.split(' ').filter((w) => w.length > 1);
    const existingRoots = existingWords.map(stripAlPrefix);

    if (candidateWords.length >= 2 && existingWords.length >= 2) {
      const sharedWords = candidateWords.filter((w) => existingWords.includes(w));
      if (sharedWords.length >= 2) {
        result.similarMatches.push({
          record,
          matchType: 'word_match',
          message: `يشترك في كلمتين: (${sharedWords.slice(0, 2).join(' و ')})`,
        });
        continue;
      }

      // Check root matches (e.g. "محمد الجبوري" vs "محمد جبوري")
      const sharedRoots = candidateRoots.filter((r) => existingRoots.includes(r));
      if (sharedRoots.length >= 2) {
        result.similarMatches.push({
          record,
          matchType: 'word_match',
          message: `يشترك في الأسماء: (${sharedRoots.slice(0, 2).join(' و ')})`,
        });
        continue;
      }
    }

    // 4. Fuzzy Levenshtein match for single-word or 2-word names
    if (candidateWords.length === 1 && existingWords.length === 1) {
      const cWord = candidateWords[0];
      const eWord = existingWords[0];
      const maxLen = Math.max(cWord.length, eWord.length);
      if (maxLen >= 4) {
        const dist = levenshteinDistance(cWord, eWord);
        if (dist === 1 || (maxLen >= 6 && dist <= 2)) {
          result.similarMatches.push({
            record,
            matchType: 'fuzzy',
            message: 'تشابه إملائي متقارب جداً',
          });
          continue;
        }
      }
    } else if (Math.abs(normCandidate.length - normExisting.length) <= 2) {
      const dist = levenshteinDistance(normCandidate, normExisting);
      if (dist === 1 || (normCandidate.length >= 7 && dist <= 2)) {
        result.similarMatches.push({
          record,
          matchType: 'fuzzy',
          message: 'تقارب كبير في الحروف والتهجئة',
        });
        continue;
      }
    }
  }

  result.hasSimilarMatches = result.similarMatches.length > 0;
  // Limit similar matches to top 4 to avoid overwhelming UI
  if (result.similarMatches.length > 4) {
    result.similarMatches = result.similarMatches.slice(0, 4);
  }

  return result;
}
